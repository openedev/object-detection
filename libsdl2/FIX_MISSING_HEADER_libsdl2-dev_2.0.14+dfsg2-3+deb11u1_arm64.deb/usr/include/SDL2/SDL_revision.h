#define SDL_REVISION "https://github.com/avafinger/SDL@"
#define SDL_REVISION_NUMBER 0
